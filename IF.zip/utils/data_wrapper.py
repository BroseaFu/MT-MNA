from typing import Dict


# 封装字典类型的数据，以方便.to(device)
class DictDataWrapper(object):
    def __init__(self, data: Dict = None):
        if data is None:
            self.data = dict()
        else:
            self.data = data

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value

    def keys(self):
        return self.data.keys()

    def values(self):
        return self.data.values()

    def to(self, device):
        for ln in self.data:
            self.data[ln] = self.data[ln].to(device)
        return self


# 封装嵌套字典类型的数据，以方便.to(device)
class NestedDictDataWrapper(object):
    def __init__(self, data):
        self.data = data

    def __getitem__(self, key):
        return self.data[key]

    def __setitem__(self, key, value):
        self.data[key] = value

    def keys(self):
        return self.data.keys()

    def values(self):
        return self.data.values()

    def to(self, device):
        for ln1 in self.data:
            for ln2 in self.data[ln1]:
                self.data[ln1][ln2] = self.data[ln1][ln2].to(device)
        return self
