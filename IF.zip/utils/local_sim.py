import torch
import numpy as np
from torch_geometric.utils import to_undirected, add_self_loops
from scipy.sparse import csr_matrix
from numpy.linalg import matrix_power


def process_local_sim(edge_index, node_nums, max_hops=2, decay_rate=0.5):
    local_sim = {}
    print('Calculate k-hop similiarity:')
    
    for layer_id in edge_index.keys():
        print('Layer {}'.format(layer_id))
        cur_edge_index = edge_index[layer_id].T
        sim_matrix = np.zeros((node_nums[layer_id], node_nums[layer_id]))
        cur_local_adj = csr_matrix((torch.ones(len(cur_edge_index)),
                                   (cur_edge_index[:, 0].cpu().tolist(),
                                    cur_edge_index[:, 1].cpu().tolist())),
                                   shape=(node_nums[layer_id], node_nums[layer_id]))
        cur_local_adj = cur_local_adj.todense()
        for k in range(1, max_hops + 1):
            adj_power = matrix_power(cur_local_adj, k)
            sim_matrix = np.where(np.logical_and(adj_power > 0, sim_matrix < decay_rate ** (k - 1)),
                                  decay_rate ** (k - 1),
                                  sim_matrix)
        # print(sim_matrix)
        local_sim[layer_id] = csr_matrix(sim_matrix)
        # print(local_sim[layer_id])
    return local_sim


if __name__ == "__main__":
    edge_index = {
        '1': add_self_loops(to_undirected(torch.tensor([[0, 1],
                                                        [0, 3],
                                                        [1, 2],
                                                        [3, 6],
                                                        [4, 5],
                                                        [4, 7],
                                                        [6, 7],
                                                        [7, 8]]).T))[0],
        '2': add_self_loops(to_undirected(torch.tensor([[0, 1],
                                                        [1, 3],
                                                        [2, 3]]).T))[0]
    }
    node_nums = {'1': 9, '2': 4}
    _ = process_local_sim(edge_index, node_nums)
