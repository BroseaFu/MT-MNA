import os
import random

import networkx as nx
import numpy as np
import pandas as pd
import torch
import torch_geometric as pyg
from tqdm.auto import tqdm


def seed_everything(seed: int = 42):
    random.seed(seed)
    os.environ['PYTHONHASHSEED'] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benckmark = False


def load_multi(path):
    '''
    读入图谱数据。
    :param
        path: 数据集存储路径。
    :return:
        layers: 多层图网络，不同层的图结构。稀疏矩阵格式存储。
        layer_node2id, layer_id2node: 多层图网络中不同层节点的映射。
        layer_cross_anchors: 跨层锚链接。
    '''
    data = pd.read_csv(path, delimiter=' ', header=None)
    data.columns = ['layer_id', 'n1', 'n2', 'weight']
    data['layer_id'] = data['layer_id'].astype(str)
    tmp = data.groupby('layer_id')
    layers = {}
    layer_node2id = {}
    layer_id2node = {}
    graphs = {}
    for layer_id, nodes in tmp:
        layers[layer_id] = []
        layer_node2id[layer_id] = {}
        node2id = {}
        id2node = {}
        for _, row in tqdm(nodes.iterrows(), total=len(nodes), desc='node2id: Layer {}'.format(layer_id)):
            if row.n1 not in node2id:
                node2id[row.n1] = len(node2id)
            if row.n2 not in node2id:
                node2id[row.n2] = len(node2id)
        layer_node2id[layer_id] = node2id

        for key in node2id:
            id2node[node2id[key]] = key
        layer_id2node[layer_id] = id2node

        for _, row in tqdm(nodes.iterrows(), total=len(nodes), desc='append_edges: Layer {}'.format(layer_id)):
            layers[layer_id].append([node2id[row.n1], node2id[row.n2]])
            # layers[layer_id].append([row.n1, row.n2])

        layers[layer_id] = torch.LongTensor(np.array(layers[layer_id]).T)
        graphs[layer_id] = nx.Graph()
        edges = [(int(layers[layer_id][0, i]), int(layers[layer_id][1, i])) for i in range(layers[layer_id].shape[1])]
        graphs[layer_id].add_edges_from(edges)
        graphs[layer_id] = graphs[layer_id].to_undirected()
        layers[layer_id] = pyg.utils.to_undirected(layers[layer_id])

    layer_cross_anchors = {}
    for layer_id in layers.keys():
        layer_cross_anchors[layer_id] = {}

    for layer_id_i in layers.keys():
        for layer_id_j in layers.keys():
            if int(layer_id_i) < int(layer_id_j):
                common_nodes = set(list(layer_node2id[layer_id_i].keys())) & set(list(layer_node2id[layer_id_j].keys()))
                cross_i_j = []
                cross_j_i = []
                for node in common_nodes:
                    cross_i_j.append([layer_node2id[layer_id_i][node], layer_node2id[layer_id_j][node]])
                    cross_j_i.append([layer_node2id[layer_id_j][node], layer_node2id[layer_id_i][node]])
                layer_cross_anchors[layer_id_i][layer_id_j] = torch.from_numpy(np.array(cross_i_j, dtype=np.int64))
                layer_cross_anchors[layer_id_j][layer_id_i] = torch.from_numpy(np.array(cross_j_i, dtype=np.int64))

    return layers, layer_node2id, layer_id2node, layer_cross_anchors, graphs


def split_anchors(anchors, test_size=0.5, sparse_annotation=False, drop_layers=None, threshold=30):
    train_anchors = {}
    test_anchors = {}
    layer_names = list(anchors.keys())
    for i in range(len(layer_names)):
        train_anchors[layer_names[i]] = {}
        test_anchors[layer_names[i]] = {}
    
    for i in range(len(layer_names)):
        layer_i = layer_names[i]
        for j in range(i + 1, len(layer_names)):
            layer_j = layer_names[j]
            idx = np.random.permutation(len(anchors[layer_i][layer_j]))
            if sparse_annotation and (len(idx) <= threshold or (layer_i, layer_j) in drop_layers):
                train_idx = []
                test_idx = idx.tolist()
            else:
                train_idx = idx[:-int(len(idx) * test_size)].tolist()
                test_idx = idx[-int(len(idx) * test_size):].tolist()
            print('G{} - G{}: train:{} test:{}'.format(layer_i, layer_j, len(train_idx), len(test_idx)))
            train_anchors[layer_i][layer_j] = anchors[layer_i][layer_j][train_idx]
            train_anchors[layer_j][layer_i] = anchors[layer_i][layer_j][train_idx][:, [1, 0]]
            test_anchors[layer_i][layer_j] = anchors[layer_i][layer_j][test_idx]
            test_anchors[layer_j][layer_i] = anchors[layer_i][layer_j][test_idx][:, [1, 0]]

    return train_anchors, test_anchors
