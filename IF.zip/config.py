from dataclasses import dataclass


@dataclass
class Config:
    # Global setting
    data_path: str = '/sdc/wwc/DMGC/IF/data/f2t_multiplex/f2t_multiplex.edges'
    # data_path: str = '/sdc/wwc/DMGC/IF/data/sacchcere/sacchcere_genetic_multiplex.edges'
    # data_path: str = '/sdc/wwc/DMGC/IF/data/arxiv/arxiv_multiplex.edges'
    use_cuda: bool = True
    cude_id: int = 0
    seed: int = 42

    # Model setting
    # Pre-trained stage
    pt_epochs: int = 50
    # Fine-tuning stage
    num_epochs: int = 500
    lr: float = 0.005
    batch_size: int = 256
    ft_dims: int = 200
    hid_dims: int = 200
    out_dims: int = 200
    num_layers: int = 3
    # Negative sampling
    num_negs: int = 2

    # Training setting
    test_size: float = 0.2
    eval_per_epoch: int = 20
    log_per_epoch: int = 1
    sparse_anno: bool = False
    # Testing setting
    eval_verbose: bool = True


args = Config()
