import torch.nn as nn
from torch_geometric.nn import GATConv, GINConv, GCNConv
from .mlp import MLP


class GNNEncoder(nn.Module):
    def __init__(self, in_features, hid_features, out_features):
        super().__init__()

        # self.fc1 = nn.Linear(in_features=in_features,
        #                      out_features=hid_features)
        # self.gnn = GATConv(in_channels=hid_features,
        #                    out_channels=hid_features)
        # self.gnn1 = GINConv(nn=MLP(in_features=hid_features,
        #                           hid_features=hid_features,
        #                           out_features=hid_features),
        #                    train_eps=True)
        # self.fc2 = nn.Linear(in_features=hid_features,
        #                      out_features=out_features)
        # self.gnn2 = GINConv(nn=MLP(in_features=hid_features,
        #                           hid_features=hid_features,
        #                           out_features=hid_features),
        #                    train_eps=True)
        self.gnn1 = GCNConv(in_channels=hid_features, out_channels=hid_features)
        self.gnn2 = GCNConv(in_channels=hid_features, out_channels=hid_features)

        self.act = nn.Tanh()

    def forward(self, x, edge_index):
        # x = self.act(self.fc1(x))
        # x = self.act(self.gnn(x, edge_index))
        # x = self.act(self.fc2(x))
        x = self.act(self.gnn1(x, edge_index))
        x = self.act(self.gnn2(x, edge_index))
        return x
