import torch
import torch.nn as nn


def inner_product(x, y):
    return torch.sum(torch.multiply(x, y), dim=1, keepdim=True)


def identity(x):
    return x


class NSLoss(nn.Module):
    def __init__(self, sim=None, act=None, loss=None):
        super().__init__()
        if sim is None:
            self.sim = inner_product
        else:
            self.sim = sim

        if act is None:
            self.act = identity
        else:
            self.act = act

        if loss is None:
            self.loss = nn.MSELoss()
        else:
            self.loss = loss

    @staticmethod
    def sample(num_negs, probs, batch_size, scale=256):
        """
        按照给定采样概率进行负采样

        Args:
            num_negs: 负采样的数量
            probs: 多项式采样的概率
            batch_size: batch size
            scale: 最大采样下标
        """
        assert num_negs >= 0
        if probs is None:
            idx = torch.Tensor(batch_size * num_negs).uniform_(0, scale).long()
        else:
            if not isinstance(probs, torch.Tensor):
                probs = torch.tensor(probs)
            idx = torch.multinomial(input=probs,
                                    num_samples=batch_size * num_negs,
                                    replacement=True)
        return idx.view(num_negs, batch_size)

    @staticmethod
    def get_weights(idx_s, idx_t, adj):
        if adj is None:
            return torch.ones(len(idx_s))
        else:
            idx_s, idx_t = idx_s.cpu().tolist(), idx_t.cpu().tolist()
            adj = adj[idx_s, idx_t]
            return torch.FloatTensor(adj).squeeze(0)

    def get_xy(self, emb_s, emb_t, idx_s, idx_t, trans_s, trans_t, num_negs, probs, adj):
        x_s, x_t = torch.embedding(emb_s, idx_s), torch.embedding(emb_t, idx_t)
        x_s, x_t = trans_s(x_s), trans_t(x_t)

        pos = self.sim(x_s, x_t).view(-1)
        y_pos = self.get_weights(idx_s, idx_t, adj)

        if num_negs > 0:
            idx_neg = self.sample(num_negs=num_negs,
                                  probs=probs,
                                  batch_size=len(idx_s),
                                  scale=len(emb_t))
            neg = torch.stack(
                [self.sim(x_s, trans_t(emb_t[i])) for i in idx_neg])
            neg = neg.view(-1)

            x = torch.cat([pos, neg])
            if adj is None:
                y_neg = torch.zeros(len(neg))
            else:
                y_neg = torch.stack([self.get_weights(idx_s, i, adj)
                                    for i in idx_neg]).view(-1)
            y = torch.cat([y_pos, y_neg])
        else:
            x = pos
            y = y_pos
        return x, y

    def forward(self, emb_s, emb_t, idx_s, idx_t, trans_s, trans_t, num_negs, probs, adj=None):
        x, y = self.get_xy(emb_s, emb_t, idx_s, idx_t,
                           trans_s, trans_t, num_negs, probs, adj)
        x = self.act(x)
        y = y.to(x.device)
        return self.loss(x, y)
