import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parameter import Parameter
import math


class SpaceTrans(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.weight = Parameter(torch.empty((in_dim, out_dim)))
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))

    def forward(self, x, transpose=False):
        if transpose:
            return F.linear(input=x, weight=self.weight, bias=None)
        else:
            return F.linear(input=x, weight=self.weight.T, bias=None)

    def __repr__(self):
        return 'SpaceTrans(in_dim={}, out_dim={})'.format(self.in_dim, self.out_dim)


# class SpaceTrans(nn.Module):
#     def __init__(self, ft_dim):
#         super().__init__()
        