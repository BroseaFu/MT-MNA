import random
import torch
import torch.nn as nn
import torch.optim as optim
import torch_geometric as pyg
from scipy.sparse import csr_matrix
from torch.utils.data import DataLoader
from torch_geometric.nn import GATConv
from config import args
from model.mlp import MLP
from model.gnn import GNNEncoder
from model.loss import NSLoss
from model.space_trans import SpaceTrans
from utils.data_wrapper import DictDataWrapper, NestedDictDataWrapper
from utils.local_sim import process_local_sim


def dummy_forward(x):
    return x


class AlignModel(torch.nn.Module):
    def __init__(self, argss, layer_names, node_nums):
        super().__init__()
        self.args = argss
        self.layer_names = layer_names
        self.node_nums = node_nums

        self.emb = nn.ModuleDict()
        # self.space_trans = nn.ModuleDict()
        # self.space_rev = nn.ModuleDict()
        self.cross_trans = nn.ModuleDict()
        self.gnn = GNNEncoder(in_features=args.ft_dims,
                              hid_features=args.hid_dims,
                              out_features=args.out_dims)

        for ln in layer_names:
            self.emb[ln] = nn.Embedding(num_embeddings=node_nums[ln],
                                        embedding_dim=args.ft_dims,
                                        max_norm=1)

            # self.space_trans[ln] = nn.Linear(in_features=args.out_dims,
            #                                  out_features=args.out_dims)
            # self.space_rev[ln] = nn.Linear(in_features=args.out_dims,
            #                                out_features=args.out_dims)

            self.cross_trans[ln] = nn.ModuleDict()
            for ln_2 in layer_names:
                if ln_2 == ln:
                    continue
                # self.cross_trans[ln][ln_2] = nn.Linear(
                #     in_features=args.out_dims,
                #     out_features=args.out_dims,
                #     bias=False)
                self.cross_trans[ln][ln_2] = SpaceTrans(
                    args.out_dims, args.out_dims)

        self.opt = optim.AdamW(self.parameters(), lr=args.lr, weight_decay=0.01)
        self.lr_sche = optim.lr_scheduler.ExponentialLR(
            self.opt, gamma=0.9, verbose=True)
        self.criteria = NSLoss(
            sim=nn.CosineSimilarity(),
            act=nn.GELU(),
            loss=nn.MSELoss()
        )
        # self.criteria = NSLoss(
        #     sim=nn.CosineSimilarity(),
        #     act=nn.Sigmoid(),
        #     loss=nn.BCELoss()
        # )

    def get_batches(self, pairs, batch_size):
        batches = DataLoader(
            pairs,
            batch_size=batch_size,
            shuffle=True
        )
        return batches

    def optimize(self, loss, epoch):
        self.opt.zero_grad()
        loss.backward()
        self.opt.step()
        # if hasattr(self, 'lr_sche') and (epoch + 1) % 50 == 0:
        #     self.lr_sche.step()

    def para_anchor_loss(self, embs, layer_s, layer_t, layer_m, pairs, adj):
        batches = self.get_batches(pairs, self.args.batch_size)
        loss_pc = 0.
        for batch in batches:
            idx_s, idx_t = batch[:, 0], batch[:, 1]
            emb_s, emb_t = embs[layer_s], embs[layer_t]
            loss = self.criteria(
                emb_s, emb_t,
                idx_s, idx_t,
                nn.Sequential(
                    self.cross_trans[layer_s][layer_m],
                    self.cross_trans[layer_m][layer_t]),
                dummy_forward,
                self.args.num_negs,
                None,
                adj
            )
            loss_pc += loss
        loss_pc /= len(batches)
        return loss_pc

    def local_loss(self, embs, layer_id, pairs, adj):
        batches = self.get_batches(pairs, self.args.batch_size)
        loss_l = 0.
        for batch in batches:
            idx_s, idx_t = batch[:, 0], batch[:, 1]
            emb_s, emb_t = embs[layer_id], embs[layer_id]
            loss = self.criteria(
                emb_s, emb_t,
                idx_s, idx_t,
                dummy_forward,
                dummy_forward,
                self.args.num_negs,
                None,
                adj
            )
            loss_l += loss
        loss_l /= len(batches)
        return loss_l

    def cross_anchor_loss(self, embs, layer_s, layer_t, pairs, adj):
        batches = self.get_batches(pairs, self.args.batch_size)
        loss_pc = 0.
        for batch in batches:
            idx_s, idx_t = batch[:, 0], batch[:, 1]
            emb_s, emb_t = embs[layer_s], embs[layer_t]
            loss = self.criteria(
                emb_s, emb_t,
                idx_s, idx_t,
                self.cross_trans[layer_s][layer_t],
                dummy_forward,
                self.args.num_negs,
                None,
                adj
            )
            loss_pc += loss
        loss_pc /= len(batches)
        return loss_pc

    def back_local_loss(self, embs, layer_s, layer_t, pairs, adj):
        batches = self.get_batches(pairs, self.args.batch_size)
        loss_pc = 0.
        for batch in batches:
            idx_s, idx_t = batch[:, 0], batch[:, 0]
            emb_s, emb_t = embs[layer_s], embs[layer_s]
            loss = self.criteria(
                emb_s, emb_t,
                idx_s, idx_t,
                nn.Sequential(
                    self.cross_trans[layer_s][layer_t],
                    self.cross_trans[layer_t][layer_s]
                ),
                dummy_forward,
                self.args.num_negs,
                None,
                adj
            )
            loss_pc += loss
        loss_pc /= len(batches)
        return loss_pc

    def get_emb(self, x_ids, edge_index):
        embs = DictDataWrapper()
        for ln in self.layer_names:
            emb = self.emb[ln](x_ids[ln])
            emb = self.gnn(emb, edge_index[ln])
            embs[ln] = emb
        return embs

    def pariwise_cosine_similarity(self, xs, ys, epsilon=1e-8):
        mat = xs @ ys.t()
        x_norm = xs.norm(2, dim=1) + epsilon
        y_norm = ys.norm(2, dim=1) + epsilon
        x_diag = (1 / x_norm).diag()
        y_diag = (1 / y_norm).diag()
        return x_diag @ mat @ y_diag

    def hits_score(self, sims, target, k):
        # 相似度分数高于目标节点分数的个数
        rank = (sims >= target).sum(1)
        rank = rank.min(torch.tensor(k + 1, device=sims.device))
        temp = (k + 1 - rank).float()
        hit_p = (temp / k).mean()
        c_p = (temp > 0).float().mean()
        return c_p, hit_p

    def hits_ij(self, emb_i, emb_j, anchors, k_list):
        sim = self.pariwise_cosine_similarity(emb_i, emb_j)
        row, col = anchors[:, 0], anchors[:, 1]
        target = sim[row, col].reshape((-1, 1))
        sim_i = sim[row]
        sim_j = sim.T[col]
        res_i2j, res_j2i = [], []
        res_ci2j, res_cj2i = [], []
        for k in k_list:
            c_i, h_i = self.hits_score(sim_i, target, k)
            c_j, h_j = self.hits_score(sim_j, target, k)
            res_i2j.append(h_i)
            res_j2i.append(h_j)
            res_ci2j.append(c_i)
            res_cj2i.append(c_j)

        return res_i2j, res_j2i, res_ci2j, res_cj2i

    @torch.no_grad()
    def evaluation(self, embs, anchors, k_list=None, verbose=True):
        if k_list is None:
            k_list = [1, 5, 10, 20, 30, 50]

        avg_hits = []
        avg_cov = []
        node_sum = []

        for l_i in range(len(self.layer_names)):
            layer_i = self.layer_names[l_i]
            for l_j in range(l_i+1, len(self.layer_names)):
                if l_j == l_i:
                    continue
                layer_j = self.layer_names[l_j]

                cur_anchors = anchors[layer_i][layer_j]
                if len(cur_anchors) == 0:
                    continue

                # emb_i = self.space_trans[layer_i](embs[layer_i])
                # emb_j = self.space_trans[layer_j](embs[layer_j])
                emb_i = self.cross_trans[layer_i][layer_j](embs[layer_i])
                emb_j = embs[layer_j]

                hits_i2j, hits_j2i, cov_i2j, cov_j2i = self.hits_ij(emb_i, emb_j, cur_anchors, k_list)
                # node_sum.extend([len(cur_anchors), len(cur_anchors)])
                # avg_hits.append(hits_i2j)
                # avg_hits.append(hits_j2i)
                node_sum.append(len(cur_anchors))
                node_sum.append(len(cur_anchors))
                avg_hits.append(hits_i2j)
                avg_cov.append(cov_i2j)
                avg_hits.append(hits_j2i)
                avg_cov.append(cov_j2i)

                if verbose:
                    print('layer_{} -> layer_{} ({}): '.format(layer_i, layer_j, len(cur_anchors)), end='')
                    for pre in hits_i2j:
                        print('{:.3f} '.format(pre), end='')
                    print('   ', end='')
                    for pre in cov_i2j:
                        print('{:.3f} '.format(pre), end='')
                    print()
                    
                    print('layer_{} -> layer_{} ({}): '.format(layer_j, layer_i, len(cur_anchors)), end='')
                    for pre in hits_j2i:
                        print('{:.3f} '.format(pre), end='')
                    print('   ', end='')
                    for pre in cov_j2i:
                        print('{:.3f} '.format(pre), end='')
                    print()
                    # print('layer_{} -> layer_{}: '.format(layer_j, layer_i), end='')
                    # for pre in hits_j2i:
                    #     print('{:.3f} '.format(pre), end='')
                    # print()

        print('Average:     1        5        10       20       30       100')
        avg_hits_ = torch.sum(
            (torch.tensor(avg_hits).T * torch.tensor(node_sum)).T, dim=0) / sum(node_sum)
        avg_cov_ = torch.sum(
            (torch.tensor(avg_cov).T * torch.tensor(node_sum)).T, dim=0) / sum(node_sum)
        print('Weighted: ', end='')
        for pre in avg_hits_:
            print('{:3f} '.format(pre.item()), end='')
        print()
        print('          ', end='')
        for pre in avg_cov_:
            print('{:3f} '.format(pre.item()), end='')
        print()
        
        avg_hits_ = torch.mean(torch.tensor(avg_hits), dim=0)
        avg_cov_ = torch.mean(torch.tensor(avg_cov), dim=0)
        print('Macro---: ', end='')
        for pre in avg_hits_:
            print('{:3f} '.format(pre.item()), end='')
        print()
        print('          ', end='')
        for pre in avg_cov_:
            print('{:3f} '.format(pre.item()), end='')
        print()

    def fit(self, x_ids, edge_index, train_anchors, test_anchors):
        # Set up training mode, not the training procession.
        self.train()
        
        local_adj = process_local_sim(edge_index, self.node_nums)
        
        for epoch in range(self.args.num_epochs):
            print(flush=True)
            loss = 0.
            embs = self.get_emb(x_ids, edge_index)
            for l_i in range(len(self.layer_names)):
                layer_i = self.layer_names[l_i]

                cur_local_anchors = edge_index[layer_i].T
                # cur_local_adj = csr_matrix((torch.ones(len(cur_local_anchors)),
                #                             (cur_local_anchors[:, 0].cpu().tolist(),
                #                              cur_local_anchors[:, 1].cpu().tolist())),
                #                            shape=(self.node_nums[layer_i], self.node_nums[layer_i]))
                cur_local_adj = local_adj[layer_i]
                # print(cur_local_anchors.shape)

                dense_anchors = torch.stack([torch.arange(self.node_nums[layer_i]),
                                             torch.arange(self.node_nums[layer_i])]).T.to(cur_local_anchors.device)

                cur_loss = 0.

                for l_j in range(len(self.layer_names)):
                    if l_j == l_i:
                        continue
                    layer_j = self.layer_names[l_j]

                    cur_anchors = train_anchors[layer_i][layer_j]
                    if len(cur_anchors) == 0:
                        continue
                    cur_adj = csr_matrix((torch.ones(len(cur_anchors)),
                                          (cur_anchors[:, 0].cpu().tolist(), cur_anchors[:, 1].cpu().tolist())),
                                         shape=(self.node_nums[layer_i], self.node_nums[layer_j]))

                    # 普通锚链接损失，将i层和j层映射到同一个隐匿空间中进行对齐
                    # anchor_loss = self.cal_anchor_loss(
                    #     embs, layer_i, layer_j, cur_anchors, cur_adj
                    # )
                    # cur_loss += anchor_loss

                    # 反转锚链接损失，将i层映射到同一隐匿空间后反转到目标层中进行对齐
                    # rev_anchor_loss = self.cal_rev_anchor_loss(
                    #     embs, layer_i, layer_j, cur_anchors, cur_adj
                    # )
                    # cur_loss += rev_anchor_loss

                    # 平行传递损失，i层为源层，j层为目标层，m层为中间传递层，将源层通过中间传递层传递至目标层中对齐
                    cand_layers = list(range(len(self.layer_names)))
                    cand_layers.remove(l_i)
                    cand_layers.remove(l_j)
                    l_m = random.choice(cand_layers)
                    layer_m = self.layer_names[l_m]
                    para_loss = self.para_anchor_loss(
                        embs, layer_i, layer_j, layer_m, cur_anchors, cur_adj
                    )

                    cand_layers.remove(l_m)
                    layer_m2 = self.layer_names[random.choice(cand_layers)]
                    para_loss_2 = self.para_anchor_loss(
                        embs, layer_i, layer_j, layer_m2, cur_anchors, cur_adj
                    )
                    # para_loss = torch.norm(torch.matmul(self.cross_trans[layer_i][layer_m].weight,
                    #                                     self.cross_trans[layer_m][layer_j].weight)
                    #                        - self.cross_trans[layer_i][layer_j].weight)
                    # print(para_loss.item())
                    cur_loss += para_loss + para_loss_2

                    # 交叉传递损失，i层为源层，j层为目标层，将源层向量映射到目标层中对齐
                    if len(cur_anchors) > 0:
                        cross_anchor_loss = self.cross_anchor_loss(
                            embs, layer_i, layer_j, cur_anchors, cur_adj
                        )
                        cur_loss += cross_anchor_loss

                    # 同层回传损失，i层为源层，j层为传递层，将源层映射到传递层再回传，与原特征向量近似
                    back_local_loss = self.back_local_loss(
                        embs, layer_i, layer_j, dense_anchors, cur_local_adj
                    )
                    cur_loss += back_local_loss

                    loss += cur_loss / len(self.layer_names)

                # 局部损失，在i层中维护同一层中节点的邻接关系
                local_loss = self.local_loss(
                    embs, layer_i, cur_local_anchors, cur_local_adj
                )
                loss += local_loss

                # 反转局部损失，将i层中节点转移到隐匿空间后反转回源空间，维护同一层中节点的邻接关系
                # rev_local_loss = self.cal_rev_local_loss(
                #     embs, layer_i, cur_local_anchors, cur_local_adj
                # )
                # loss += rev_local_loss

            self.optimize(loss, epoch)

            if (epoch + 1) % self.args.log_per_epoch == 0:
                print('Epoch {}/{}: loss={:.5f}'.format(epoch +
                    1, self.args.num_epochs, loss))
            if (epoch + 1) % self.args.eval_per_epoch == 0:
                print("Training:")
                self.evaluation(embs, train_anchors,
                                verbose=self.args.eval_verbose)
                print("Testing:")
                self.evaluation(embs, test_anchors,
                                verbose=self.args.eval_verbose)

    def choose_path(self, x_ids, edge_index, anchors):
        embs = self.get_emb(x_ids, edge_index)
        ln_i = self.layer_names[0]
        ln_j = self.layer_names[2]
        anchor = anchors[ln_i][ln_j]
        row, col = anchor[:, 0], anchor[:, 1]
        emb_i = embs[ln_i][row]
        emb_j = embs[ln_j][col]

        sim_dir = torch.cosine_similarity(self.cross_trans[ln_i][ln_j](emb_i), emb_j)
        sim_pass_1 = torch.cosine_similarity(self.cross_trans['2'][ln_j](self.cross_trans[ln_i]['2'](emb_i)), emb_j)
        sim_pass_2 = torch.cosine_similarity(self.cross_trans['4'][ln_j](self.cross_trans[ln_i]['4'](emb_i)), emb_j)

        # sim_dir = self.pariwise_cosine_similarity(self.cross_trans[ln_i][ln_j](emb_i), emb_j)
        # sim_pass_1 = self.pariwise_cosine_similarity(self.cross_trans['2'][ln_j](self.cross_trans[ln_i]['2'](emb_i)), emb_j)
        # sim_pass_2 = self.pariwise_cosine_similarity(self.cross_trans['4'][ln_j](self.cross_trans[ln_i]['4'](emb_i)), emb_j)

        for i in range(len(sim_dir)):
            print('{:5d} {:5d} {:.3f} {:.3f} {:.3f}'.format(row[i], col[i], sim_dir[i], sim_pass_1[i], sim_pass_2[i]))
        # hits_i2j, hits_j2i, cov_i2j, cov_j2i = self.hits_ij(emb_i, emb_j, anchor, [1, 5, 10, 20, 30, 50])



    def forward(self, x_ids, edge_index):
        pass
