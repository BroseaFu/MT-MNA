import torch

from config import args
from utils.load_data import seed_everything, load_multi, split_anchors
from utils.data_wrapper import DictDataWrapper, NestedDictDataWrapper
from model.multi_align import AlignModel

seed_everything(args.seed)

edge_index, node2id, id2node, anchors, graphs = load_multi(args.data_path)
train_anchors, test_anchors = split_anchors(anchors, test_size=args.test_size, sparse_annotation=args.sparse_anno,
                                             drop_layers=[('2', '3'),
                                                          ('2', '4'),
                                                          ('3', '4'),
                                                          ('3', '2'),
                                                          ('4', '2'),
                                                          ('4', '3'),])

if args.use_cuda:
    device = torch.device('cuda:' + str(args.cude_id))
else:
    device = torch.device('cpu')

layer_names = list(edge_index.keys())
x_ids = dict()
node_nums = dict()
for ln in layer_names:
    x_ids[ln] = torch.arange(len(node2id[ln]))
    node_nums[ln] = len(node2id[ln])

print('Move all component to device.')
model = AlignModel(args, layer_names, node_nums)
model.to(device)
print(model)

x_ids = DictDataWrapper(x_ids).to(device)
edge_index = DictDataWrapper(edge_index).to(device)
train_anchors = NestedDictDataWrapper(train_anchors).to(device)
test_anchors = NestedDictDataWrapper(test_anchors).to(device)

model.fit(x_ids, edge_index, train_anchors, test_anchors)

torch.save(model, 'checkpoint_{}.pt'.format(args.num_epochs))